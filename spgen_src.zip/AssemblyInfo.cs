using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("SPGen")]
[assembly: AssemblyDescription("Stored Procedure Code Generator")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Bluegrass Technologies")]
[assembly: AssemblyProduct("SPGen")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]		

[assembly: AssemblyVersion("1.1.*")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]